declare interface IMiiProfileQualificationsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MiiProfileQualificationsWebPartStrings' {
  const strings: IMiiProfileQualificationsWebPartStrings;
  export = strings;
}
