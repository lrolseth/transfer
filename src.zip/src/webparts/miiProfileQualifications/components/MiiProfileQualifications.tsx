import * as React from "react";
import styles from "./MiiProfileQualifications.module.scss";
import { IMiiProfileQualificationsProps } from "./IMiiProfileQualificationsProps";
import { escape } from "@microsoft/sp-lodash-subset";

export default class MiiProfileQualifications extends React.Component<
  IMiiProfileQualificationsProps,
  {}
> {
  public render(): React.ReactElement<IMiiProfileQualificationsProps> {
    return (
      <div className={styles.miiProfileQualifications}>
        <div className={styles.container}>
          <div className={styles.topLine}></div>
          <div className={styles.innerContainer}>
            <div className={styles.iconColumn}>
              <img src={require("../assets/check.svg")} alt="Qualifications" />
            </div>
            <div className={styles.contentColumn}>
              <div className={styles.sectionTitle}>Qualifications</div>
              <div className={styles.sectionBody}>
                <div>
                  <div className={styles.column1}>Roles</div>
                  <div className={styles.column2}>content</div>
                </div>
                <div>
                  <div className={styles.column1}>Skills</div>
                  <div className={styles.column2}>content</div>
                </div>
                <div>
                  <div className={styles.column1}>Industry Experience</div>
                  <div className={styles.column2}>content</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
