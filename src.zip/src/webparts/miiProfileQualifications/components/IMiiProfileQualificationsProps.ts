export interface IMiiProfileQualificationsProps {
  description: string;
}
