/* tslint:disable */
require("./MiiProfileQualifications.module.css");
const styles = {
  miiProfileQualifications: 'miiProfileQualifications_2d6d4679',
  container: 'container_2d6d4679',
  topLine: 'topLine_2d6d4679',
  innerContainer: 'innerContainer_2d6d4679',
  iconColumn: 'iconColumn_2d6d4679',
  contentColumn: 'contentColumn_2d6d4679',
  sectionTitle: 'sectionTitle_2d6d4679',
  sectionBody: 'sectionBody_2d6d4679',
  column1: 'column1_2d6d4679',
  column2: 'column2_2d6d4679'
};

export default styles;
/* tslint:enable */