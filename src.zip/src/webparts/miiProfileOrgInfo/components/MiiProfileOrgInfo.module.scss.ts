/* tslint:disable */
require("./MiiProfileOrgInfo.module.css");
const styles = {
  miiProfileOrgInfo: 'miiProfileOrgInfo_36d262b5',
  container: 'container_36d262b5',
  topLine: 'topLine_36d262b5',
  innerContainer: 'innerContainer_36d262b5',
  iconColumn: 'iconColumn_36d262b5',
  contentColumn: 'contentColumn_36d262b5',
  sectionTitle: 'sectionTitle_36d262b5',
  sectionBody: 'sectionBody_36d262b5',
  column1: 'column1_36d262b5',
  column2: 'column2_36d262b5'
};

export default styles;
/* tslint:enable */