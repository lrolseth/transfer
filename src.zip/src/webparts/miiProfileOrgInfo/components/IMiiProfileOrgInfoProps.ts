import { IProfileUser } from "../../../models/IProfileUser";

export interface IMiiProfileOrgInfoProps {
  profileUser: IProfileUser;

  // enterprise: string;
  // businessUnit: string;
  // region: string;
  // country: string;
  // location: string;
  // languages: string;
}
