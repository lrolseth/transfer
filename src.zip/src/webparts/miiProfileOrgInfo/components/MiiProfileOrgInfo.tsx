import * as React from "react";
import styles from "./MiiProfileOrgInfo.module.scss";
import { IMiiProfileOrgInfoProps } from "./IMiiProfileOrgInfoProps";
import { escape } from "@microsoft/sp-lodash-subset";

export default class MiiProfileOrgInfo extends React.Component<
  IMiiProfileOrgInfoProps,
  {}
> {
  public render(): React.ReactElement<IMiiProfileOrgInfoProps> {
    return (
      <div className={styles.miiProfileOrgInfo}>
        <div className={styles.container}>
          <div className={styles.topLine}></div>
          <div className={styles.innerContainer}>
            <div className={styles.iconColumn}>
              <img src={require("../assets/org.svg")} alt="Org Info" />
            </div>
            <div className={styles.contentColumn}>
              <div className={styles.sectionTitle}>Org Info</div>
              <div className={styles.sectionBody}>
                <div>
                  <div className={styles.column1}>Enterprise</div>
                  <div className={styles.column2}>
                    {this.props.profileUser.businessUnit}
                  </div>
                </div>
                <div>
                  <div className={styles.column1}>Group or Function</div>
                  <div className={styles.column2}>
                    {this.props.profileUser.platform}
                  </div>
                </div>
                <div>
                  <div className={styles.column1}>Region</div>
                  <div className={styles.column2}>
                    {this.props.profileUser.region}
                  </div>
                </div>
                <div>
                  <div className={styles.column1}>State/Province</div>
                  <div className={styles.column2}>
                    {this.props.profileUser.location}
                  </div>
                </div>
                <div>
                  <div className={styles.column1}>Country</div>
                  <div className={styles.column2}>
                    {this.props.profileUser.country}
                  </div>
                </div>
                <div>
                  <div className={styles.column1}>Languages</div>
                  <div className={styles.column2}>content</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
