import * as React from "react";
import * as ReactDom from "react-dom";
import {
  Version,
  Environment,
  EnvironmentType,
} from "@microsoft/sp-core-library";
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField,
} from "@microsoft/sp-property-pane";
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";

import * as strings from "MiiProfileOrgInfoWebPartStrings";
import MiiProfileOrgInfo from "./components/MiiProfileOrgInfo";
import { IMiiProfileOrgInfoProps } from "./components/IMiiProfileOrgInfoProps";
import { UrlQueryParameterCollection } from "@microsoft/sp-core-library";

import { IListService } from "../../services/ListService/IListService";
import { ListService } from "../../services/ListService/ListService";
import MockListService from "../../services/ListService/MockListService";

import { IUserProfileService } from "../../services/UserProfileService/IUserProfileService";
import MockUserProfileService from "../../services/UserProfileService/MockUserProfileService";
import UserProfileService from "../../services/UserProfileService/UserProfileService";

import * as pnp from "@pnp/sp";
import { IProfileUser } from "../../models/IProfileUser";
import MYCONSTANTS from "../../common/constants";

export interface IMiiProfileOrgInfoWebPartProps {
  description: string;
}

export default class MiiProfileOrgInfoWebPart extends BaseClientSideWebPart<
  IMiiProfileOrgInfoWebPartProps
> {
  private listService: IListService;
  private userProfileService: IUserProfileService;
  private profileUser: IProfileUser;
  private countryOptions: any[];

  protected onInit(): Promise<void> {
    return super.onInit().then(async (_) => {
      pnp.sp.setup({
        spfxContext: this.context,
      });

      if (DEBUG && Environment.type === EnvironmentType.Local) {
        this.listService = new MockListService();
        this.userProfileService = new MockUserProfileService();
      } else {
        this.listService = new ListService();
        this.userProfileService = new UserProfileService();
      }

      //get the PID querystring
      let queryParms = new UrlQueryParameterCollection(window.location.href);
      let pid = queryParms.getValue("pid");

      if (pid) {
        //query the Nework Members list
        const memberList = await this.listService.loadMemberListByItemID(pid);

        if (memberList && memberList.MemberName["UserName"]) {
          //query the SP user profile
          //Note - memberList.MemberName["UserName"] looks like an email address
          const delveProfile = await this.userProfileService.getSPUserProfile(
            memberList.MemberName["UserName"]
          );

          //is this me?
          const currentUserEmail = await this.userProfileService.getMyUserProperty(
            MYCONSTANTS.DELVE_EMAIL
          );
          this.profileUser.isThisMe = false;
          if (currentUserEmail == memberList.MemberName["UserName"]) {
            this.profileUser.isThisMe = true;
          }

          //load the user profile properties nicely
          var delveProps = this.userProfileService.formatUserProfileProps(
            delveProfile
          );

          if (delveProfile) {
            if (memberList["LinkedInURL"]) {
              this.profileUser.linkedIn = memberList["LinkedInURL"];
            }

            if (memberList["Location"]) {
              this.profileUser.location = memberList["Location"];
            }

            if (delveProps) {
              if (delveProps["PreferredName"]) {
                this.profileUser.preferredName = delveProps["PreferredName"];
              }
              if (delveProps["WorkEmail"]) {
                this.profileUser.workEmail = delveProps["WorkEmail"];
              }
              if (delveProps["WorkPhone"]) {
                this.profileUser.workPhone = delveProps["WorkPhone"];
              }
              if (delveProps["Title"]) {
                this.profileUser.jobTitle = delveProps["Title"];
              }
              if (delveProps["Department"]) {
                this.profileUser.department = delveProps["Department"];
              }
              if (delveProps["BusinessUnit"]) {
                this.profileUser.businessUnit = delveProps["BusinessUnit"];
              }
              if (memberList["About"]) {
                this.profileUser.about = memberList["About"];
              }
              if (delveProps["Platform"]) {
                this.profileUser.platform = delveProps["Platform"];
              }
            }
          }
        }
      }
    });
  }

  public render(): void {
    const element: React.ReactElement<IMiiProfileOrgInfoProps> = React.createElement(
      MiiProfileOrgInfo,
      {
        profileUser: this.profileUser,
      }
    );

    ReactDom.render(element, this.domElement);
  }

  // public render(): void {
  //   const element: React.ReactElement<IMiiProfileOrgInfoProps> = React.createElement(
  //     MiiProfileOrgInfo,
  //     {
  //       enterprise: this.profileUser.enterprise,
  //       businessUnit: this.profileUser.businessUnit,
  //       region: this.profileUser.region,
  //       country: this.profileUser.country,
  //       location: this.profileUser.location,
  //       languages: this.profileUser.languages,
  //     }
  //   );

  //   ReactDom.render(element, this.domElement);
  // }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse("1.0");
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription,
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField("description", {
                  label: strings.DescriptionFieldLabel,
                }),
              ],
            },
          ],
        },
      ],
    };
  }
}
