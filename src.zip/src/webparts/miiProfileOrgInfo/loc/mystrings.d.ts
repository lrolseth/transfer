declare interface IMiiProfileOrgInfoWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MiiProfileOrgInfoWebPartStrings' {
  const strings: IMiiProfileOrgInfoWebPartStrings;
  export = strings;
}
