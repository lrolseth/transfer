import * as React from "react";
import * as ReactDom from "react-dom";
import {
  Version,
  Environment,
  EnvironmentType,
} from "@microsoft/sp-core-library";
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField,
} from "@microsoft/sp-property-pane";
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";

import * as strings from "MiiCompareListToDelveWebPartStrings";
import MiiCompareListToDelve from "./components/MiiCompareListToDelve";
import { IMiiCompareListToDelveProps } from "./components/IMiiCompareListToDelveProps";

import { IListService } from "../../services/ListService/IListService";
import { ListService } from "../../services/ListService/ListService";
import MockListService from "../../services/ListService/MockListService";

import { IUserProfileService } from "../../services/UserProfileService/IUserProfileService";
import MockUserProfileService from "../../services/UserProfileService/MockUserProfileService";
import UserProfileService from "../../services/UserProfileService/UserProfileService";

import * as pnp from "@pnp/sp";
import MYCONSTANTS from "../../common/constants";
import { IProfileForCompare } from "../../models/IProfileForCompare";

export interface IMiiCompareListToDelveWebPartProps {
  description: string;
}

export default class MiiCompareListToDelveWebPart extends BaseClientSideWebPart<
  IMiiCompareListToDelveWebPartProps
> {
  private listService: IListService;
  private userProfileService: IUserProfileService;
  private profileUsers: IProfileForCompare[] = [];

  protected onInit(): Promise<void> {
    return super.onInit().then(async (_) => {
      pnp.sp.setup({
        spfxContext: this.context,
      });

      if (DEBUG && Environment.type === EnvironmentType.Local) {
        this.listService = new MockListService();
        this.userProfileService = new MockUserProfileService();
      } else {
        this.listService = new ListService();
        this.userProfileService = new UserProfileService();
      }

      //query the Nework Members list
      const memberList = await this.listService.loadMemberList();

      if (memberList) {
        console.log(memberList);
        memberList.map(async (memberItem: any) => {
          let profileUser: IProfileForCompare = {
            networkMemberID: 0,
            login: "",

            list_EmailAddress: null,
            list_JobTitle: null,
            list_MIIRegion: null,
            list_Country: null,
            list_MIIBusinessUnit: null,
            list_Location: null,
            list_Enterprise: null,

            delve_PreferredName: null,
            delve_WorkEmail: null,
            delve_Title: null,
            delve_Department: null,
            delve_BusinessUnit: null,
            delve_Platform: null,
          };

          //Load network member list data first
          if (memberItem["EmailAddress"]) {
            profileUser.list_EmailAddress = memberItem["EmailAddress"];
          }

          if (memberItem["JobTitle"]) {
            profileUser.list_JobTitle = memberItem["JobTitle"];
          }
          if (memberItem["Country"]) {
            profileUser.list_Country = memberItem["Country"];
          }
          if (memberItem["MIIBusinessUnit"]) {
            profileUser.list_MIIBusinessUnit = memberItem["MIIBusinessUnit"];
          }
          if (memberItem["Location"]) {
            profileUser.list_Location = memberItem["Location"];
          }
          if (memberItem["Enterprise"]) {
            profileUser.list_Enterprise = memberItem["Enterprise"];
          }

          //query the SP user profile
          //Note - memberList.MemberName["UserName"] looks like an email address
          const delveProfile = await this.userProfileService.getSPUserProfile(
            memberItem["EmailAddress"]
          );

          //load the user profile properties nicely
          var delveProps = this.userProfileService.formatUserProfileProps(
            delveProfile
          );

          //Load the delve profile data
          if (delveProfile) {
            if (delveProps) {
              if (delveProps["PreferredName"]) {
                profileUser.delve_PreferredName = delveProps["PreferredName"];
              }
              if (delveProps["WorkEmail"]) {
                profileUser.delve_WorkEmail = delveProps["WorkEmail"];
              }

              if (delveProps["Title"]) {
                profileUser.delve_Title = delveProps["Title"];
              }
              if (delveProps["Department"]) {
                profileUser.delve_Department = delveProps["Department"];
              }
              if (delveProps["BusinessUnit"]) {
                profileUser.delve_BusinessUnit = delveProps["BusinessUnit"];
              }

              if (delveProps["Platform"]) {
                profileUser.delve_Platform = delveProps["Platform"];
              }
            }
          }

          this.profileUsers.push(profileUser);
        });
      }
    });
  }

  public render(): void {
    const element: React.ReactElement<IMiiCompareListToDelveProps> = React.createElement(
      MiiCompareListToDelve,
      {
        profileUsers: this.profileUsers,
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse("1.0");
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription,
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField("description", {
                  label: strings.DescriptionFieldLabel,
                }),
              ],
            },
          ],
        },
      ],
    };
  }
}
