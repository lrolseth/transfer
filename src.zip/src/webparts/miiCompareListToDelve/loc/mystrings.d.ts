declare interface IMiiCompareListToDelveWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MiiCompareListToDelveWebPartStrings' {
  const strings: IMiiCompareListToDelveWebPartStrings;
  export = strings;
}
