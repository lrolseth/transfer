/* tslint:disable */
require("./MiiCompareListToDelve.module.css");
const styles = {
  demo3: 'demo3_e1f1248c',
  container: 'container_e1f1248c',
  row: 'row_e1f1248c',
  webpartTitle: 'webpartTitle_e1f1248c'
};

export default styles;
/* tslint:enable */