import { IProfileForCompare } from "../../../models/IProfileForCompare";

export interface IMiiCompareListToDelveProps {
  profileUsers: IProfileForCompare[];
}
