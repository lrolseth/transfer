import * as React from "react";
import styles from "./MiiCompareListToDelve.module.scss";
import { IMiiCompareListToDelveProps } from "./IMiiCompareListToDelveProps";
import { escape } from "@microsoft/sp-lodash-subset";
import { IProfileForCompare } from "../../../models/IProfileForCompare";

import {
  DetailsList,
  IColumn,
  DetailsListLayoutMode,
  ConstrainMode,
  SelectionMode,
} from "office-ui-fabric-react/lib/DetailsList";

export interface IDemo3State {
  items: any[];
  columns: IColumn[];
}

export default class MiiCompareListToDelve extends React.Component<
  IMiiCompareListToDelveProps,
  IDemo3State
> {
  constructor(props: IMiiCompareListToDelveProps) {
    super(props);
    this.state = {
      items: [],
      columns: [],
    };
  }

  public componentDidMount = () => {
    this._buildDataList();
    // tslint:disable-next-line:semicolon
  };

  public componentDidUpdate = (prevProps: IMiiCompareListToDelveProps) => {
    if (prevProps.profileUsers !== this.props.profileUsers) {
      this._buildDataList();
    }
    // tslint:disable-next-line:semicolon
  };

  private _buildColumns = (columns: string[]): IColumn[] => {
    let cols: IColumn[] = [];
    if (columns && columns.length > 0) {
      columns.map((col: string) => {
        cols.push({ key: col, name: col, fieldName: col } as IColumn);
      });
    }
    return cols;
    // tslint:disable-next-line:semicolon
  };

  public _buildDataList = () => {
    let dataItems: any[] = [];

    if (this.props.profileUsers) {
      console.log(this.props.profileUsers);

      let parsedJson = this.props.profileUsers;
      let _dynamicColumns: string[] = [
        "delve_BusinessUnit",
        "delve_Department",
        "delve_Platform",
        "delve_PreferredName",
        "delve_Title",
        "delve_WorkEmail",
        "list_Country",
        "list_EmailAddress",
        "list_Enterprise",
        "list_JobTitle",
        "list_Location",
        "list_MIIBusinessUnit",
        "list_MIIRegion",
        "login",
        "networkMemberID",
      ];

      this.props.profileUsers.map((prof: IProfileForCompare) => {
        /*
        let dataItem = {
          delve_BusinessUnit: prof["delve_BusinessUnit"],
          delve_Department: prof["delve_Department"],
          delve_Platform: prof["delve_Platform"],
          delve_PreferredName: prof["delve_PreferredName"],
          delve_Title: prof["delve_Title"],
          delve_WorkEmail: prof["delve_WorkEmail"],
          list_Country: prof["list_Country"],
          list_EmailAddress: prof["list_EmailAddress"],
          list_Enterprise: prof["list_Enterprise"],
          list_JobTitle: prof["list_JobTitle"],
          list_Location: prof["list_Location"],
          list_MIIBusinessUnit: prof["list_MIIBusinessUnit"],
          list_MIIRegion: prof["list_MIIRegion"],
          login: prof["login"],
          networkMemberID: prof["networkMemberID"],
        };
        */

        let dataItem = [
          prof.delve_BusinessUnit,
          prof.delve_Department,
          prof.delve_Platform,
          prof.delve_PreferredName,
          prof.delve_Title,
          prof.delve_WorkEmail,
          prof.list_Country,
          prof.list_EmailAddress,
          prof.list_Enterprise,
          prof.list_JobTitle,
          prof.list_Location,
          prof.list_MIIBusinessUnit,
          prof.list_MIIRegion,
          prof.login,
          prof.networkMemberID,
        ];

        dataItems.push(dataItem);
      });

      // if (parsedJson[0]) {
      //   Object.keys(parsedJson[0]).map((key) => {
      //     _dynamicColumns.push(key);
      //   });
      this.setState({
        columns: this._buildColumns(_dynamicColumns),
        items: dataItems,
      });
      //}
    }
    // tslint:disable-next-line:semicolon
  };

  public render(): React.ReactElement<IMiiCompareListToDelveProps> {
    const { items, columns } = this.state;
    console.log("items");
    console.log(items);
    console.log("columns");
    console.log(columns);
    return (
      <div className={styles.demo3}>
        <div className={styles.container}>
          <div className={styles.row}>
            <DetailsList
              items={items}
              setKey="set"
              columns={columns}
              compact={true}
              layoutMode={DetailsListLayoutMode.justified}
              constrainMode={ConstrainMode.unconstrained}
              isHeaderVisible={true}
              selectionMode={SelectionMode.none}
              enableShimmer={true}
            />
          </div>
        </div>
      </div>
    );
  }
}
