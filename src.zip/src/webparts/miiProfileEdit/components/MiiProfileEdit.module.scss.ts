/* tslint:disable */
require("./MiiProfileEdit.module.css");
const styles = {
  miiProfileEdit: 'miiProfileEdit_cfa077e4',
  container: 'container_cfa077e4',
  row: 'row_cfa077e4',
  column: 'column_cfa077e4',
  'ms-Grid': 'ms-Grid_cfa077e4',
  title: 'title_cfa077e4',
  subTitle: 'subTitle_cfa077e4',
  description: 'description_cfa077e4',
  button: 'button_cfa077e4',
  label: 'label_cfa077e4'
};

export default styles;
/* tslint:enable */