export interface IMiiProfileEditProps {
  description: string;
}
