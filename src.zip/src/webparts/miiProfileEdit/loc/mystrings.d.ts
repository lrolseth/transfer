declare interface IMiiProfileEditWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MiiProfileEditWebPartStrings' {
  const strings: IMiiProfileEditWebPartStrings;
  export = strings;
}
