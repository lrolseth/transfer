import * as React from "react";
import styles from "./MiiProfileBadges.module.scss";
import { IMiiProfileBadgesProps } from "./IMiiProfileBadgesProps";
import { escape } from "@microsoft/sp-lodash-subset";

export default class MiiProfileBadges extends React.Component<
  IMiiProfileBadgesProps,
  {}
> {
  public render(): React.ReactElement<IMiiProfileBadgesProps> {
    return (
      <div className={styles.miiProfileBadges}>
        <div className={styles.container}>
          <div className={styles.topLine}></div>
          <div className={styles.innerContainer}>
            <div className={styles.iconColumn}>
              <img src={require("../assets/belt.svg")} alt="Badges" />
            </div>
            <div className={styles.contentColumn}>
              <div className={styles.sectionTitle}>
                Badges and Certifications
              </div>
              <div className={styles.sectionBody}>
                data
                <div className={styles.column1}>Label</div>
                <div className={styles.column2}>content</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
