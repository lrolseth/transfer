/* tslint:disable */
require("./MiiProfileBadges.module.css");
const styles = {
  miiProfileBadges: 'miiProfileBadges_dda70ff7',
  container: 'container_dda70ff7',
  topLine: 'topLine_dda70ff7',
  innerContainer: 'innerContainer_dda70ff7',
  iconColumn: 'iconColumn_dda70ff7',
  contentColumn: 'contentColumn_dda70ff7',
  sectionTitle: 'sectionTitle_dda70ff7',
  sectionBody: 'sectionBody_dda70ff7',
  column1: 'column1_dda70ff7',
  column2: 'column2_dda70ff7'
};

export default styles;
/* tslint:enable */