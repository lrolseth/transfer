export interface IMiiProfileBadgesProps {
  description: string;
}
