declare interface IMiiProfileBadgesWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MiiProfileBadgesWebPartStrings' {
  const strings: IMiiProfileBadgesWebPartStrings;
  export = strings;
}
