import * as React from "react";
import styles from "./MiiProfileClasses.module.scss";
import { IMiiProfileClassesProps } from "./IMiiProfileClassesProps";
import { escape } from "@microsoft/sp-lodash-subset";

export default class MiiProfileClasses extends React.Component<
  IMiiProfileClassesProps,
  {}
> {
  public render(): React.ReactElement<IMiiProfileClassesProps> {
    return (
      <div className={styles.miiProfileClasses}>
        <div className={styles.container}>
          <div className={styles.topLine}></div>
          <div className={styles.innerContainer}>
            <div className={styles.iconColumn}>
              <img src={require("../assets/cap.svg")} alt="Classes Taken" />
            </div>
            <div className={styles.contentColumn}>
              <div className={styles.sectionTitle}>Classes Taken</div>
              <div className={styles.sectionBody}>
                data
                <div className={styles.column1}>Label</div>
                <div className={styles.column2}>content</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
