/* tslint:disable */
require("./MiiProfileClasses.module.css");
const styles = {
  miiProfileClasses: 'miiProfileClasses_4c7ec1a2',
  container: 'container_4c7ec1a2',
  topLine: 'topLine_4c7ec1a2',
  innerContainer: 'innerContainer_4c7ec1a2',
  iconColumn: 'iconColumn_4c7ec1a2',
  contentColumn: 'contentColumn_4c7ec1a2',
  sectionTitle: 'sectionTitle_4c7ec1a2',
  sectionBody: 'sectionBody_4c7ec1a2',
  column1: 'column1_4c7ec1a2',
  column2: 'column2_4c7ec1a2'
};

export default styles;
/* tslint:enable */