export interface IMiiProfileClassesProps {
  description: string;
}
