declare interface IMiiProfileClassesWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MiiProfileClassesWebPartStrings' {
  const strings: IMiiProfileClassesWebPartStrings;
  export = strings;
}
