export interface IMiiProfileExperienceProps {
  description: string;
}
