import * as React from "react";
import styles from "./MiiProfileExperience.module.scss";
import { IMiiProfileExperienceProps } from "./IMiiProfileExperienceProps";
import { escape } from "@microsoft/sp-lodash-subset";

export default class MiiProfileExperience extends React.Component<
  IMiiProfileExperienceProps,
  {}
> {
  public render(): React.ReactElement<IMiiProfileExperienceProps> {
    return (
      <div className={styles.miiProfileExperience}>
        <div className={styles.container}>
          <div className={styles.topLine}></div>
          <div className={styles.innerContainer}>
            <div className={styles.iconColumn}>
              <img src={require("../assets/list.svg")} alt="Work Experience" />
            </div>
            <div className={styles.contentColumn}>
              <div className={styles.sectionTitle}>Work Experience</div>
              <div className={styles.sectionBody}>data</div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
