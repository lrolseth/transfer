/* tslint:disable */
require("./MiiProfileExperience.module.css");
const styles = {
  miiProfileExperience: 'miiProfileExperience_92485dfb',
  container: 'container_92485dfb',
  topLine: 'topLine_92485dfb',
  innerContainer: 'innerContainer_92485dfb',
  iconColumn: 'iconColumn_92485dfb',
  contentColumn: 'contentColumn_92485dfb',
  sectionTitle: 'sectionTitle_92485dfb',
  sectionBody: 'sectionBody_92485dfb',
  column1: 'column1_92485dfb',
  column2: 'column2_92485dfb'
};

export default styles;
/* tslint:enable */