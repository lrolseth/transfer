declare interface IMiiProfileExperienceWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MiiProfileExperienceWebPartStrings' {
  const strings: IMiiProfileExperienceWebPartStrings;
  export = strings;
}
