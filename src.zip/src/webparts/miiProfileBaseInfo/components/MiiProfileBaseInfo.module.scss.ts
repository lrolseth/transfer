/* tslint:disable */
require("./MiiProfileBaseInfo.module.css");
const styles = {
  miiProfileBaseInfo: 'miiProfileBaseInfo_ba633626',
  container: 'container_ba633626',
  personaTile: 'personaTile_ba633626',
  persona: 'persona_ba633626',
  'ms-Persona-secondaryText': 'ms-Persona-secondaryText_ba633626',
  sectionWPTitle: 'sectionWPTitle_ba633626',
  paddedText: 'paddedText_ba633626'
};

export default styles;
/* tslint:enable */