import { PageContext } from "@microsoft/sp-page-context";

export interface IMiiProfileBaseInfoProps {
  pageContext: PageContext;
  displayName: string;
  jobTitle: string;
  imageUrl: string;
  businessUnit: string;
  group: string;
  workEmail: string;
  workPhone: string;
}
