import * as React from "react";
import styles from "./MiiProfileBaseInfo.module.scss";
import { IMiiProfileBaseInfoProps } from "./IMiiProfileBaseInfoProps";
import { escape } from "@microsoft/sp-lodash-subset";
import {
  Persona,
  PersonaSize,
  IPersonaProps,
} from "office-ui-fabric-react/lib/Persona";
import {
  TooltipHost,
  TooltipOverflowMode,
  DirectionalHint,
} from "office-ui-fabric-react/lib/Tooltip";
import { Icon, ImageIcon } from "office-ui-fabric-react/lib/Icon";

export default class MiiProfileBaseInfo extends React.Component<
  IMiiProfileBaseInfoProps,
  {}
> {
  public render(): React.ReactElement<IMiiProfileBaseInfoProps> {
    const pictureUrl = `${this.props.pageContext.web.serverRelativeUrl}/_layouts/15/UserPhoto.aspx?size=m&userName=${this.props.workEmail}&default=none`;
    const emailAddress = "mailto:" + this.props.workEmail;
    const secondaryDisplay = this.props.jobTitle;
    const tertiaryDisplay = this.props.businessUnit + " " + this.props.group;

    return (
      <div className={styles.miiProfileBaseInfo}>
        <div className={styles.container}>
          <Persona
            onRenderPrimaryText={this._onRenderPrimary(this.props.displayName)}
            imageUrl={this.props.imageUrl}
            size={PersonaSize.size100}
            className={styles.persona}
            imageInitials="true"
            secondaryText={this.props.jobTitle}
            onRenderTertiaryText={this._onRenderTertiary(
              this.props.businessUnit,
              this.props.group
            )}
            onRenderOptionalText={this._onRenderOptional(
              this.props.workPhone,
              this.props.workEmail
            )}
          />
        </div>
      </div>
    );
  }

  private _onRenderText(text: string | undefined) {
    // return default render behaviour for valid text or undefined
    return text
      ? (): JSX.Element => {
          // default onRender behaviour
          return (
            <TooltipHost
              content={text}
              overflowMode={TooltipOverflowMode.Parent}
              directionalHint={DirectionalHint.topLeftEdge}
            >
              {text}
            </TooltipHost>
          );
        }
      : undefined;
  }

  private _onRenderPrimary(text: string | undefined) {
    // return default render behaviour for valid text or undefined
    return (): JSX.Element => {
      // default onRender behaviour
      return (
        <TooltipHost
          content={text}
          overflowMode={TooltipOverflowMode.Parent}
          directionalHint={DirectionalHint.topLeftEdge}
        >
          <div className={styles.sectionWPTitle}>{text}</div>
        </TooltipHost>
      );
    };
  }

  private _onRenderTertiary(bu: string, group: string) {
    return (): JSX.Element => {
      return (
        <TooltipHost
          content={bu}
          overflowMode={TooltipOverflowMode.Parent}
          directionalHint={DirectionalHint.topLeftEdge}
        >
          <div>{bu}</div>
          <div>{group}</div>
        </TooltipHost>
      );
    };
  }

  private _onRenderOptional(phone: string, email: string) {
    const emailAddress = "mailto:" + email;

    return (): JSX.Element => {
      return (
        <TooltipHost
          content={""}
          overflowMode={TooltipOverflowMode.Parent}
          directionalHint={DirectionalHint.topLeftEdge}
        >
          <hr />
          <div>
            <i className="ms-Icon ms-Icon--Phone"></i>
            <span className={styles.paddedText}>{phone}</span>
            <a href={emailAddress}>
              <i className="ms-Icon ms-Icon--Mail"></i>
              <span className={styles.paddedText}>Send Email</span>
            </a>
          </div>
        </TooltipHost>
      );
    };
  }
}
