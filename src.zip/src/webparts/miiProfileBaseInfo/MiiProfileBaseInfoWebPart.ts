import * as React from "react";
import * as ReactDom from "react-dom";
import { Version } from "@microsoft/sp-core-library";
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField,
} from "@microsoft/sp-property-pane";
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";

import * as strings from "MiiProfileBaseInfoWebPartStrings";
import MiiProfileBaseInfo from "./components/MiiProfileBaseInfo";
import { IMiiProfileBaseInfoProps } from "./components/IMiiProfileBaseInfoProps";
import { sp } from "@pnp/sp";

export interface IMiiProfileBaseInfoWebPartProps {
  description: string;
}

export default class MiiProfileBaseInfoWebPart extends BaseClientSideWebPart<
  IMiiProfileBaseInfoWebPartProps
> {
  public render(): void {
    const element: React.ReactElement<IMiiProfileBaseInfoProps> = React.createElement(
      MiiProfileBaseInfo,
      {
        pageContext: this.context.pageContext,
        displayName: "Laura Rawlings",
        jobTitle: "Contractor",
        imageUrl:
          "https://cargillonline-my.sharepoint.com:443/User%20Photos/Profile%20Pictures/laura_rawlings_crgl-thirdparty_com_MThumb.jpg",
        businessUnit: "Business Operations & Supply Chain",
        group: "Plant Systems & Controls",
        workEmail: "laura_rawlings@crgl-thirdparty.com",
        workPhone: "612-240-3325",
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse("1.0");
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription,
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField("description", {
                  label: strings.DescriptionFieldLabel,
                }),
              ],
            },
          ],
        },
      ],
    };
  }
}
