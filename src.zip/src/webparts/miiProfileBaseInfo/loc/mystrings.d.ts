declare interface IMiiProfileBaseInfoWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MiiProfileBaseInfoWebPartStrings' {
  const strings: IMiiProfileBaseInfoWebPartStrings;
  export = strings;
}
