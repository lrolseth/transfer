declare interface IMiiProfileProjectsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MiiProfileProjectsWebPartStrings' {
  const strings: IMiiProfileProjectsWebPartStrings;
  export = strings;
}
