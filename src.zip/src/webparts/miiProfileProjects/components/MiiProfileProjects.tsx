import * as React from "react";
import styles from "./MiiProfileProjects.module.scss";
import { IMiiProfileProjectsProps } from "./IMiiProfileProjectsProps";
import { escape } from "@microsoft/sp-lodash-subset";

export default class MiiProfileProjects extends React.Component<
  IMiiProfileProjectsProps,
  {}
> {
  public render(): React.ReactElement<IMiiProfileProjectsProps> {
    return (
      <div className={styles.miiProfileProjects}>
        <div className={styles.container}>
          <div className={styles.topLine}></div>
          <div className={styles.innerContainer}>
            <div className={styles.iconColumn}>
              <img src={require("../assets/run.svg")} alt="Sprints" />
            </div>
            <div className={styles.contentColumn}>
              <div className={styles.sectionTitle}>Sprints</div>
              <div className={styles.sectionBody}>
                data
                <div className={styles.column1}>Label</div>
                <div className={styles.column2}>content</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
