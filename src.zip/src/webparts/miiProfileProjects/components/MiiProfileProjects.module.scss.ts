/* tslint:disable */
require("./MiiProfileProjects.module.css");
const styles = {
  miiProfileProjects: 'miiProfileProjects_60e2696a',
  container: 'container_60e2696a',
  topLine: 'topLine_60e2696a',
  innerContainer: 'innerContainer_60e2696a',
  iconColumn: 'iconColumn_60e2696a',
  contentColumn: 'contentColumn_60e2696a',
  sectionTitle: 'sectionTitle_60e2696a',
  sectionBody: 'sectionBody_60e2696a',
  column1: 'column1_60e2696a',
  column2: 'column2_60e2696a'
};

export default styles;
/* tslint:enable */