export interface IMiiProfileProjectsProps {
  description: string;
}
