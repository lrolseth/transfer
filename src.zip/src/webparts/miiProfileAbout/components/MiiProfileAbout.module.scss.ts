/* tslint:disable */
require("./MiiProfileAbout.module.css");
const styles = {
  miiProfileAbout: 'miiProfileAbout_d2d903de',
  container: 'container_d2d903de',
  topLine: 'topLine_d2d903de',
  innerContainer: 'innerContainer_d2d903de',
  iconColumn: 'iconColumn_d2d903de',
  contentColumn: 'contentColumn_d2d903de',
  sectionTitle: 'sectionTitle_d2d903de',
  sectionBody: 'sectionBody_d2d903de',
  column1: 'column1_d2d903de',
  column2: 'column2_d2d903de'
};

export default styles;
/* tslint:enable */