export interface IMiiProfileAboutProps {
  description: string;
}
