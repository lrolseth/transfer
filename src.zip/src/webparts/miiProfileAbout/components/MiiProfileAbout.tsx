import * as React from "react";
import styles from "./MiiProfileAbout.module.scss";
import { IMiiProfileAboutProps } from "./IMiiProfileAboutProps";
import { escape } from "@microsoft/sp-lodash-subset";

export default class MiiProfileAbout extends React.Component<
  IMiiProfileAboutProps,
  {}
> {
  public render(): React.ReactElement<IMiiProfileAboutProps> {
    return (
      <div className={styles.miiProfileAbout}>
        <div className={styles.container}>
          <div className={styles.topLine}></div>
          <div className={styles.innerContainer}>
            <div className={styles.iconColumn}>
              <img src={require("../assets/about.svg")} alt="About Me" />
            </div>
            <div className={styles.contentColumn}>
              <div className={styles.sectionTitle}>About Me</div>
              <div className={styles.sectionBody}>data</div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
