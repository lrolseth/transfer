declare interface IMiiProfileAboutWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MiiProfileAboutWebPartStrings' {
  const strings: IMiiProfileAboutWebPartStrings;
  export = strings;
}
