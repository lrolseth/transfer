import { WebPartContext } from "@microsoft/sp-webpart-base";
import { sp } from "@pnp/sp";
import { IProfileUser } from "../models/IProfileUser";

// Class Services
export default class SPListDataService {
  constructor(private context: WebPartContext) {
    sp.setup({
      spfxContext: this.context,
    });

    // graph.setup({
    //   spfxContext: this.context,
    // });
    // Init
    this.onInit();
  }
  // OnInit Function
  private async onInit() {}

  /**
   *
   *
   * @param {string} siteUrl
   * @param {string} listName
   * @param {number} eventId
   * @returns {Promise<IEventData>}
   * @memberof spservices

  public async getNetworkMemberOrgInfo(
    listName: string,
    memberID: number
  ): Promise<IProfileUser> {
    let returnedProfileUser: IProfileUser = undefined;

    try {
      let linkedIn = "";
      let login = "";
      let imageUrl = "";
      let location = "";
      let displayName = "";
      let workEmail = "";
      let workPhone = "";
      let jobTitle = "";
      let state = "";
      let region = "";
      let country = "";
      let department = "";
      let businessUnit = "";
      let groupOrFunction = "";
      let languages = "";

      //sp.web.lists.getByTitle('Network Members').items.getById(791).select('ID','MemberName/UserName','MemberName/ID',"EmailAddress",           "Enterprise",           "MIIBusinessUnit",           "MIIRegion",           "Country",           "Location",           "LinkedInURL",           "Languages",           "ID").expand('MemberName').get()

      const memberList = await sp.web.lists
        .getByTitle(listName)
        .items.usingCaching()
        .getById(memberID)
        .select(
          "Enterprise",
          "MIIBusinessUnit",
          "MIIRegion",
          "Country",
          "Location",
          "Languages",
          "ID"
        );

      if (memberList["Enterprise"]) {
        groupOrFunction = memberList["Enterprise"];
      }
      if (memberList["MIIBusinessUnit"]) {
        businessUnit = memberList["MIIBusinessUnit"];
      }
      if (memberList["MIIRegion"]) {
        region = memberList["MIIRegion"];
      }
      if (memberList["Country"]) {
        country = memberList["Country"];
      }
      if (memberList["Location"]) {
        location = memberList["Location"];
      }
      if (memberList["Languages"]) {
        languages = memberList["Languages"];
      }

      returnedProfileUser = {
        networkMemberID: memberID,
        login: login,
        displayName: displayName,
        imageUrl: imageUrl,
        workEmail: workEmail,
        workPhone: workPhone,
        jobTitle: jobTitle,
        location: location,
        state: state,
        region: region,
        country: country,
        department: department,
        businessUnit: businessUnit,
        groupOrFunction: groupOrFunction,
        about: null,
        linkedIn: linkedIn,
        languages: languages,
      };
    } catch (error) {
      return Promise.reject(error);
    }
    return returnedProfileUser;
  }

  public async getNetworkMemberAbout(
    listName: string,
    memberID: number
  ): Promise<IProfileUser> {
    let returnedProfileUser: IProfileUser = undefined;

    try {
      let login = "";
      let about = "";

      const memberList = await sp.web.lists
        .getByTitle(listName)
        .items.usingCaching()
        .getById(memberID)
        .select("MemberName/Id", "About");

      if (memberList["MemberName/Id"]) {
        login = memberList["MemberName/Id"];
      }

      if (memberList["About"]) {
        about = memberList["About"];
      }

      returnedProfileUser = {
        networkMemberID: memberID,
        login: login,
        about: about,
        displayName: null,
        imageUrl: null,
        workEmail: null,
        workPhone: null,
        jobTitle: null,
        location: null,
        state: null,
        region: null,
        country: null,
        department: null,
        businessUnit: null,
        groupOrFunction: null,
        linkedIn: null,
        //badges: Badge[];
        //classes: Course[];
        //projects: Project[];
        //languages: Language[];
        //roles: Role[];
        //skills: Skill[];
        //industries: Industry[];
      };
    } catch (error) {
      return Promise.reject(error);
    }
    return returnedProfileUser;
  }

  public async getNetworkMemberQualifications(
    listName: string,
    memberID: number
  ): Promise<IProfileUser> {
    let returnedProfileUser: IProfileUser = undefined;

    try {
      let linkedIn = "";
      let login = "";
      let imageUrl = "";
      let location = "";
      let displayName = "";
      let workEmail = "";
      let workPhone = "";
      let jobTitle = "";
      let state = "";
      let region = "";
      let country = "";
      let department = "";
      let businessUnit = "";
      let groupOrFunction = "";
      let about = "";
      // let platform = "";
      // let skills = "";
      // let certifications = "";
      // let experience = "";

      const memberList = await sp.web.lists
        .getByTitle(listName)
        .items.usingCaching()
        .getById(memberID)
        .select(
          "MemberName/Id",
          "MemberName/UserName",
          "About",
          "LinkedInURL",
          "Location",
          "ID"
        );

      if (memberList["About"]) {
        login = memberList["About"];
      }
      if (memberList["About"]) {
        displayName = memberList["About"];
      }
      if (memberList["About"]) {
        imageUrl = memberList["About"];
      }
      if (memberList["About"]) {
        workEmail = memberList["About"];
      }
      if (memberList["About"]) {
        workPhone = memberList["About"];
      }
      if (memberList["About"]) {
        jobTitle = memberList["About"];
      }
      if (memberList["department"]) {
        location = memberList["About"];
      }
      if (memberList["department"]) {
        state = memberList["About"];
      }
      if (memberList["department"]) {
        region = memberList["About"];
      }
      if (memberList["department"]) {
        country = memberList["About"];
      }

      if (memberList["businessUnit"]) {
        businessUnit = memberList["About"];
      }
      if (memberList["businessUnit"]) {
        groupOrFunction = memberList["About"];
      }
      if (memberList["businessUnit"]) {
        department = memberList["About"];
      }

      if (memberList["About"]) {
        about = memberList["About"];
      }
      if (memberList["About"]) {
        linkedIn = memberList["About"];
      }
      // if (memberList["InnovationSkills"]) {
      //   skills = memberList["InnovationSkills"];
      // }

      // if (memberList["Certifications"]) {
      //   certifications = memberList["Certifications"];
      // }

      // if (memberList["Experience"]) {
      //   experience = memberList["Experience"];
      // }

      returnedProfileUser = {
        networkMemberID: memberID,
        login: login,
        displayName: displayName,
        imageUrl: imageUrl,
        workEmail: workEmail,
        workPhone: workPhone,
        jobTitle: jobTitle,
        location: location,
        state: state,
        region: region,
        country: country,
        department: department,
        businessUnit: businessUnit,
        groupOrFunction: groupOrFunction,
        about: about,
        linkedIn: linkedIn,
        //badges: Badge[];
        //classes: Course[];
        //projects: Project[];
        //languages: Language[];
        //roles: Role[];
        //skills: Skill[];
        //industries: Industry[];
      };
    } catch (error) {
      return Promise.reject(error);
    }
    return returnedProfileUser;
  }
*/
}
