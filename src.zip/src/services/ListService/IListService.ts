import { IPropertyPaneDropdownOption } from "@microsoft/sp-property-pane";
import { IProfileUser } from "../../models/IProfileUser";

export interface IListService {
  loadControls(): Promise<IPropertyPaneDropdownOption[]>;
  getCountryContent(controlID: string, country: string): Promise<any>;
  getCountries(): Promise<any>;
  loadMemberListByItemID(pid: string): Promise<any>;
  loadMemberList(): Promise<any>;
}
