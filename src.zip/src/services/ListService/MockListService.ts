import { IListService } from "./IListService";
import { IPropertyPaneDropdownOption } from "@microsoft/sp-property-pane";
import { IProfileUser } from "../../models/IProfileUser";

export default class MockListService implements IListService {
  constructor() {}

  public loadControls(): Promise<IPropertyPaneDropdownOption[]> {
    const ddlOptions: IPropertyPaneDropdownOption[] = [];
    ddlOptions.push({ key: "1", text: "1id" + " - " + "ListTitle1" });
    ddlOptions.push({ key: "2", text: "2id" + " - " + "ListTitle2" });

    return new Promise<IPropertyPaneDropdownOption[]>((resolve) => {
      setTimeout(() => {
        resolve(ddlOptions);
      }, 1000);
    });
  }

  public getCountryContent(controlID: string, country: string): Promise<any> {
    var filterText =
      "This is the country content for ControlId eq " +
      controlID +
      "and Country/Title eq '" +
      country +
      "'"; //query by the name not the ID

    return new Promise<any>((resolve) => {
      setTimeout(() => {
        resolve(filterText);
      }, 1000);
    });
  }

  public getCountries(): Promise<any> {
    const ddlOptions: IPropertyPaneDropdownOption[] = [];
    ddlOptions.push({ key: "1", text: "UnitedStates" });
    ddlOptions.push({ key: "2", text: "zzTest" });

    return new Promise<IPropertyPaneDropdownOption[]>((resolve) => {
      setTimeout(() => {
        resolve(ddlOptions);
      }, 1000);
    });
  }

  public loadMemberListByItemID(pid): Promise<any> {
    let memberInfo = [
      { LinkedInUrl: "www.google.com" },
      { Location: "River Falls" },
      { UserName: "lrolseth@yahoo.com" },
    ];

    return new Promise<any>((resolve) => {
      setTimeout(() => {
        resolve(memberInfo);
      }, 1000);
    });
  }

  public loadMemberList(): Promise<any> {
    let memberInfo = [
      { LinkedInUrl: "www.google.com" },
      { Location: "River Falls" },
      { UserName: "lrolseth@yahoo.com" },
    ];

    return new Promise<any>((resolve) => {
      setTimeout(() => {
        resolve(memberInfo);
      }, 1000);
    });
  }
}
