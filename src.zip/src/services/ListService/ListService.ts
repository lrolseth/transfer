import { Text } from "@microsoft/sp-core-library";
import { SPHttpClient } from "@microsoft/sp-http";
import { sp } from "@pnp/sp/presets/all";
import { handleError } from "../../common/handleError";

import { IPropertyPaneDropdownOption } from "@microsoft/sp-property-pane";

import { IListService } from "./IListService";
import { IProfileUser } from "../../models/IProfileUser";

export class ListService implements IListService {
  public loadControls(): Promise<IPropertyPaneDropdownOption[]> {
    return new Promise<IPropertyPaneDropdownOption[]>((resolve) => {
      sp.web.lists
        .getByTitle("Controls")
        .items.select("ID", "Title")
        .get()
        .then((response: any) => {
          let ddlOptions: IPropertyPaneDropdownOption[] = [];
          response.map((item: any) => {
            ddlOptions.push({
              key: item.ID,
              text: item.ID + " - " + item.Title,
            });
          });

          resolve(ddlOptions);
        })
        .catch(async (e) => {
          await handleError(e);
        });
    });
  }

  public getCountryContent(controlID: string, country: string): Promise<any> {
    return new Promise<any>((resolve) => {
      var filterText =
        "ControlId eq " + controlID + "and Country/Title eq '" + country + "'"; //query by the name not the ID
      sp.web.lists
        .getByTitle("CountryContent")
        .items.filter(filterText)
        .select(
          "ID",
          "Title",
          "Content",
          "Country/ID",
          "Country/Title",
          "Control/ID",
          "ContentTypeId",
          "URL"
        )
        .expand("Control,Country")
        .get()
        .then((result: any) => {
          //pull just the first row of content.
          let reply = null;

          if (result && result[0]) {
            reply = result[0];
          }

          if (reply) {
            if (
              //is this a link?
              reply["ContentTypeId"] ==
              "0x01050026BA4B0F8D3D464E83A80E80B8C550AA"
            ) {
              if (reply["URL"] != null) {
                var res = reply["URL"];
                reply = res.Url; //it is broken into url and display text
              }
            } else {
              if (reply["Content"]) {
                reply = reply["Content"];
              }
            }
          }

          resolve(reply);
        })
        .catch(async (e) => {
          await handleError(e);
        });
    });
  }

  public getCountries(): Promise<any> {
    return sp.web.lists
      .getByTitle("Countries")
      .items.select("Title")
      .orderBy("Title")
      .get()
      .then((response: any) => {
        return response;
      })
      .catch(async (e) => {
        await handleError(e);
      });
  }

  public loadMemberListByItemID(pid): Promise<any> {
    return null;
  }

  public loadMemberList(): Promise<any> {
    return sp.web.lists
      .getByTitle("Network Members")
      .items.orderBy("MemberName")
      .get()
      .then((response: any) => {
        return response;
      })
      .catch(async (e) => {
        await handleError(e);
      });
  }
}
