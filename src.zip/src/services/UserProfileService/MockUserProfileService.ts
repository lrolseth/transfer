import { IUserProfileService } from "./IUserProfileService";

export default class MockUserProfileService implements IUserProfileService {
  constructor() {}

  public getMyUserProperty(propName: string): Promise<string> {
    let propValue: string = "";

    if (propName == "Country") {
      propValue = "United States";
    }
    if (propName == "GlobalTravelBaseCountry") {
      propValue = "ZZTest";
    }

    return new Promise<string>((resolve) => {
      setTimeout(() => {
        resolve(propValue);
      }, 1000);
    });
  }

  public getUserProperty(
    accountName: string,
    propName: string
  ): Promise<string> {
    return null;
  }
  public updateUserProperty(accountName, propName, value) {}

  public async getUserProfile(login) {
    return null;
  }

  public formatUserProfileProps(user) {
    //for this mock, no cleaning is needed
    return user;
  }

  public async getSPUserProfile(login) {
    let profile = [
      { PreferredName: "Laura Rawlings" },
      { WorkEmail: "lrolseth@yahoo.com" },
      { WorkPhone: "715-555-1212" },
      { Title: "Senior Consultant" },
      { Department: "DBOS" },
      { BusinessUnit: "Smart Manufacturing" },
      { About: "Hello. This is about me." },
      { Platform: "my platform" },
    ];

    return new Promise<any>((resolve) => {
      setTimeout(() => {
        resolve(profile);
      }, 1000);
    });
  }
}
