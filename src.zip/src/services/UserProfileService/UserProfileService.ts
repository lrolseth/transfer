import { IUserProfileService } from "./IUserProfileService";
import { sp } from "@pnp/sp/presets/all";
import { handleError } from "../../common/handleError";
import * as _ from "lodash";
import MYCONSTANTS from "../../common/constants";

export default class MockUserProfileService implements IUserProfileService {
  constructor() {}

  public getMyUserProperty(propName: string): Promise<string> {
    return new Promise<string>((resolve) => {
      sp.profiles.myProperties
        .get()
        .then((result) => {
          var propProperty = _.filter(result["UserProfileProperties"], {
            Key: propName,
          })[0];
          var propValue = propProperty["Value"] ? propProperty["Value"] : "";

          resolve(propValue);
        })
        .catch(async (e) => {
          await handleError(e);
        });
    });
  }

  public getUserProperty(login: string, propName: string): Promise<string> {
    //convert the email to a directory accountname
    login = "i:0#.f|membership|" + login;
    return new Promise<string>((resolve) => {
      sp.profiles
        .getPropertiesFor(login)
        .then((result) => {
          var propProperty = _.filter(result["UserProfileProperties"], {
            Key: propName,
          })[0];
          var propValue = propProperty["Value"] ? propProperty["Value"] : "";

          resolve(propValue);
        })
        .catch(async (e) => {
          await handleError(e);
        });
    });
  }

  public updateUserProperty(accountName, propName, value) {
    var result = sp.profiles
      .setSingleValueProfileProperty(accountName, propName, value)
      .catch(async (e) => {
        await handleError(e);
      });
  }

  public formatUserProfileProps(user) {
    // Properties are stored in inconvenient Key/Value pairs,
    // so parse into an object called userProperties
    let properties = {};
    if (user && user.UserProfileProperties) {
      user.UserProfileProperties.map((prop: any) => {
        properties[prop.Key] = prop.Value;
      });
      user.userProperties = properties;
    }
    return properties;
  }

  public async getSPUserProfile(login) {
    //convert the email to a directory accountname
    login = "i:0#.f|membership|" + login;
    return sp.profiles.getPropertiesFor(login).then((r) => {
      return r;
    });
  }
}
