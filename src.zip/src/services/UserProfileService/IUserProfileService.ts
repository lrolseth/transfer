export interface IUserProfileService {
  getMyUserProperty(propName: string): Promise<string>;
  getUserProperty(accountName: string, propName: string): Promise<string>;
  updateUserProperty(accountName: string, propName: string, value: string);
  getSPUserProfile(login: string): any;
  formatUserProfileProps(user): any;
}
