export default class MYCONSTANTS {
  public static BOOKING_LINK_NUMBER = "24";
  public static EXPENSE_LINK_NUMBER = "26";
  public static PROFILE_LINK_NUMBER = "28";
  public static FORM_LINK_NUMBER = "30";
  public static AGENCY_ADDRESS_NUMBER = "29";
  public static BOOKING_SUBHTML_NUMBER = "57";
  public static NOCOUNTRY_NUMBER = "47";

  public static DELVE_EMAIL = "Email";
  public static DELVE_COUNTRY = "Country";
  public static DELVE_GLOBALTRAVELBASECOUNTRY = "GlobalTravelBaseCountry";
  public static DELVE_ACCOUNTNAME = "AccountName";
  public static DELVE_FIRSTNAME = "FirstName";
  public static DELVE_ENTERPRISE = "Enterprise";
  public static DELVE_BUSINESSUNIT = "BusinessUnit";
}
