export interface IRole {
  title: string;
}
