export interface ICourse {
  title: string;
}
