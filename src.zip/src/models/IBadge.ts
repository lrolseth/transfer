export interface IBadge {
  title: string;
}
