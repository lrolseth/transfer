export interface IProject {
  title: string;
}
