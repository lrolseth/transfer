export interface ILanguage {
  title: string;
}
