export interface IProfileForCompare {
  networkMemberID: number;
  login: string;

  list_EmailAddress: string;
  list_JobTitle: string;
  list_MIIRegion: string | any;
  list_Country: string | any;
  list_MIIBusinessUnit: string | any;
  list_Location: string;
  list_Enterprise: string;

  delve_PreferredName: string;
  delve_WorkEmail: string;
  delve_Title: string;
  delve_Department: string;
  delve_BusinessUnit: string;
  delve_Platform: string;
}
