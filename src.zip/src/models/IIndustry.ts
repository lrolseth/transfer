export interface IIndustry {
  title: string;
}
