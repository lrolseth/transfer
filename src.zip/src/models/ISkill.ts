export interface ISkill {
  title: string;
}
