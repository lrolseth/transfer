import { IBadge } from "./IBadge";
import { ICourse } from "./ICourse";
import { IProject } from "./IProject";
import { ILanguage } from "./ILanguage";
import { IRole } from "./IRole";
import { ISkill } from "./ISkill";
import { IIndustry } from "./IIndustry";

export interface IProfileUser {
  networkMemberID: number;
  login: string;
  displayName: string | any;
  preferredName: string;
  imageUrl: string | any;
  workEmail: string | any;
  workPhone: string | any;
  jobTitle: string | any;
  location: string | any;
  department: string | any;
  businessUnit: string | any;
  groupOrFunction: string | any;
  platform: string;
  state: string | any;
  region: string | any;
  country: string | any;
  about: string | any;
  linkedIn: string | any;
  languages: string | any;
  isThisMe: boolean;
  // badges: Badge[];
  // classes: Course[];
  // projects: Project[];
  // languages: Language[];
  // roles: Role[];
  // skills: Skill[];
  // industries: Industry[];
}
