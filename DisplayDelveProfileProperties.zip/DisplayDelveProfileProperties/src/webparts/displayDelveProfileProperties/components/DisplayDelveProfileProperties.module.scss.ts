/* tslint:disable */
require("./DisplayDelveProfileProperties.module.css");
const styles = {
  displayDelveProfileProperties: 'displayDelveProfileProperties_0a5cbad7',
  container: 'container_0a5cbad7',
  row: 'row_0a5cbad7',
  column: 'column_0a5cbad7',
  'ms-Grid': 'ms-Grid_0a5cbad7',
  title: 'title_0a5cbad7',
  subTitle: 'subTitle_0a5cbad7',
  description: 'description_0a5cbad7',
  button: 'button_0a5cbad7',
  label: 'label_0a5cbad7',
};

export default styles;
/* tslint:enable */