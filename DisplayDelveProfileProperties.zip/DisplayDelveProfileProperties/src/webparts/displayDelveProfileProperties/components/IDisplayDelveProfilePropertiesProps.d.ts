export interface IDisplayDelveProfilePropertiesProps {
    description: string;
}
