import * as React from "react";
import { IDisplayDelveProfilePropertiesProps } from "./IDisplayDelveProfilePropertiesProps";
export default class DisplayDelveProfileProperties extends React.Component<IDisplayDelveProfilePropertiesProps, {}> {
    private displayAllProperties();
    componentDidMount(): void;
    render(): React.ReactElement<IDisplayDelveProfilePropertiesProps>;
}
