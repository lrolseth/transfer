import * as React from "react";
import styles from "./DisplayDelveProfileProperties.module.scss";
import { IDisplayDelveProfilePropertiesProps } from "./IDisplayDelveProfilePropertiesProps";
import { escape } from "@microsoft/sp-lodash-subset";
import pnp from "@pnp/pnpjs";

export default class DisplayDelveProfileProperties extends React.Component<
  IDisplayDelveProfilePropertiesProps,
  {}
> {
  private displayAllProperties() {
    pnp.sp.profiles.myProperties
      .get()
      .then(result => {
        var props = result.UserProfileProperties;
        var propValue = "";
        props.forEach(prop => {
          propValue += prop.Key + " - " + prop.Value + "<br/>";
        });
        document.getElementById("content").innerHTML = propValue;
      })
      .catch(err => {
        console.log("Error: " + err);
      });
  }

  public componentDidMount(): void {
    this.displayAllProperties();
  }

  public render(): React.ReactElement<IDisplayDelveProfilePropertiesProps> {
    return (
      <div className={styles.displayDelveProfileProperties}>
        <div className={styles.container}>
          <div className={styles.row}>
            <div className={styles.column}>
              <div id="content" />
            </div>
          </div>
        </div>
      </div>
    );
  }
}
