declare interface IDisplayDelveProfilePropertiesWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'DisplayDelveProfilePropertiesWebPartStrings' {
  const strings: IDisplayDelveProfilePropertiesWebPartStrings;
  export = strings;
}
